<?php

// Intentionally left blank
class RefundTest extends TestCase
{
    public function testTrue()
    {
        $this->assertEquals("equal", "equal");
    }
    
}
