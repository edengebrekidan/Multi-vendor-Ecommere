<?php

class Shippo_ApiError extends Shippo_Error
{
}
