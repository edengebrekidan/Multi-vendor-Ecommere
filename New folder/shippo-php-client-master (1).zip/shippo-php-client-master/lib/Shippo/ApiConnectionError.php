<?php

class Shippo_ApiConnectionError extends Shippo_Error
{
}
